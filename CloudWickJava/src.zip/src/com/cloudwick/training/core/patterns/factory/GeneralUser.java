package com.cloudwick.training.core.patterns.factory;

public class GeneralUser implements IUser {
	
	public void printResult(){
		System.out.println("General processing");
	}

}
