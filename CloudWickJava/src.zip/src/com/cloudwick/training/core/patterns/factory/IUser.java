package com.cloudwick.training.core.patterns.factory;

public interface IUser {

	public void printResult();
}
