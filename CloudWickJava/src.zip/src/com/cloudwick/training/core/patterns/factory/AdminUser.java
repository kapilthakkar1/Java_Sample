package com.cloudwick.training.core.patterns.factory;

public class AdminUser implements IUser{
	
	public void printResult(){
		System.out.println("Admin processing");
	}

}
