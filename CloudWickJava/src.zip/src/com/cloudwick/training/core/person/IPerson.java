package com.cloudwick.training.core.person;

public interface IPerson {
public int cal(int n1,int n2);

}
