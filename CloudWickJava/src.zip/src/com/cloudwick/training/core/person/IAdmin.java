package com.cloudwick.training.core.person;

public interface IAdmin {
public int getAge();
}
