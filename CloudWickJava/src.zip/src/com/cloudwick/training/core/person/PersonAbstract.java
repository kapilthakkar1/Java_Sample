package com.cloudwick.training.core.person;

public abstract class PersonAbstract {
	
	public void abstractPrint(){
		
		System.out.println("printing abstract");
	}

	public abstract int getnumber(int i);
	  
}
