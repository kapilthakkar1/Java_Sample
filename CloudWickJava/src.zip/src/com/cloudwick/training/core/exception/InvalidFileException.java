package com.cloudwick.training.core.exception;

import javax.naming.directory.InvalidSearchFilterException;

public class InvalidFileException extends Exception{
	
	public InvalidFileException(String msg){
		super(msg);
	}

}
