package com.cloudwick.training.core.json;

public class AddressJSON {

	public String office;
	public String home;
	
	public AddressJSON(String office, String home)
	{
		this.office=office;
		this.home=home;
		
	}
	
	public AddressJSON(){
		
	}
	
}
